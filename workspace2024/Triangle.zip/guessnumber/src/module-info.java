import javax.swing.jOptionPane;

public class GuessNmber {

	public static void
	JOptionPane.showMessageDialog(null,"The number is "+

(1 + (int)(Math.random() * 10)));