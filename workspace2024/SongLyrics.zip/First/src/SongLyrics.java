
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Unsealed on a porch a letter sat Then you said 'I wanna leave it again'");
		// TODO Auto-generated method stub

	}

}
