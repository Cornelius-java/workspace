
public class MovieQuote {	
	public static void main(String[] args) {
		System.out.println("Revenge of the Sith");
		System.out.println("I am the senate");
		System.out.println("Emperor Palpatine");
		System.out.println("Year 2005");

	}

}
